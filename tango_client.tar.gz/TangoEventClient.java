/*----- PROTECTED REGION ID(LMCDS.imports) ENABLED START -----*/

/*----- PROTECTED REGION END -----*/	//	LMCDS.imports

import fr.esrf.TangoDs.Except;
import fr.esrf.TangoDs.TangoConst;
import fr.esrf.Tango.DevFailed;
import fr.esrf.Tango.DevState;
import fr.esrf.TangoApi.CallBack;
import fr.esrf.TangoApi.events.EventData;
import fr.esrf.TangoApi.AttributeInfo;
import fr.esrf.TangoApi.DeviceAttribute;
import fr.esrf.TangoApi.DeviceProxy;
import fr.esrf.TangoApi.Connection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class TangoEventClient extends DeviceProxy {

    private DeviceProxy deviceProxy, devAdm;
    private EventCallback callback;
    private int subscribed_event;

    public TangoEventClient(String deviceName) throws DevFailed {
        deviceProxy = new DeviceProxy(deviceName);
        DevState devstate = deviceProxy.state();
	System.out.println("========== STATE "  + deviceName );
        System.out.println(devstate + "\n");
	long pingvar = deviceProxy.ping();
	System.out.println(" Ping Status : " + Long.toString(pingvar)) ;
	System.out.println(" get_timeout_millis  : " + Integer.toString(deviceProxy.get_timeout_millis()) ) ;
	System.out.println(" Access Control ? : " + Integer.toString( deviceProxy.getAccessControl()) );

	devAdm = deviceProxy.get_adm_dev();
        pingvar = devAdm.ping();
	System.out.println(" deviceAdm Ping Status : " + Long.toString(pingvar)) ;
	String devAdmName = devAdm.fullName();
	System.err.println( "DeviceAdm Information : " + devAdmName);
        System.err.println( "DeviceAdm Timeout     : " + Integer.toString(devAdm.getDev_timeout()) );

        AttributeInfo[] ac = devAdm.get_attribute_info(); 
	for (int i=0 ; i < ac.length ; i++) {
              System.out.println(ac[i].name + " . " + ac[i].description);
        }

	deviceProxy.set_transparency_reconnection(false);

	Thread LMCDevThread = new Thread(new LMCDevStat());
        LMCDevThread.setName(LMCDevStat.class.getCanonicalName());
        LMCDevThread.start();
    }

    public void subscribeToAttribute(String attributeName) throws DevFailed {

	callback = new EventCallback();
        subscribed_event = deviceProxy.subscribe_event(attributeName, TangoConst.CHANGE_EVENT, callback, new String[] {}, true );
	System.out.println( "\n\nSubscribed_event :"+ Integer.toString(subscribed_event) );
    }


    public void setDevTimeout(int mstime ) {

	 try {


	    if ( deviceProxy.get_timeout_millis() != mstime )
	    {
                 System.out.println("\n######### setDevTimeout : " + Integer.toString(mstime) + " getTimeout : " + Integer.toString( deviceProxy.get_timeout_millis() ) );
	         deviceProxy.setDev_timeout(mstime);
	         deviceProxy.set_timeout_millis(mstime);
	         devAdm.set_timeout_millis(mstime);
                 devAdm.setDev_timeout(mstime);
            }
	 } catch ( DevFailed e ) {
            System.err.println("setDevTimeout() Error :- " + e.errors[0].desc);
	 } catch (Exception e ) {
            System.err.println("setDevTimeout() Error :- " + e.getMessage());
         }
    }

    public void unsubscribeFromAttribute(String attributeName) throws DevFailed {
         deviceProxy.unsubscribe_event(subscribed_event);
	 // TBD CHECK setDevTimeout(5);
    }

    private class EventCallback extends CallBack {

        public void push_event(EventData eventData) {
            if (eventData.err) {
                System.err.println("Error receiving event: " + eventData.errors[0].desc);
                return;
            }
            try {
                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

                DeviceAttribute myattr = eventData.attr_value;
                AttributeInfo ac = deviceProxy.get_attribute_info("counter");

                String data = ac.name;

                // --- AVOID TOO MUCH PRINTING --- System.out.println("EVENT received for attribute: " + ac.name);
		// Event is straing Event-Name
		LocalDateTime currentDateTime = LocalDateTime.now();
		String curtime = currentDateTime.format(myFormatObj);

                System.out.print("Event-Time  : "+ curtime + " EVENT : "  + eventData.event);

                DeviceAttribute value = eventData.attr_value;
		if ( value.hasFailed()) {
			Except.print_exception(value.getErrStack());
		}else {
                    try {
                        if (value.getType() == TangoConst.Tango_DEV_LONG) {
                            System.out.print(" counter value " + value.extractLong());
                        }
                    } catch (DevFailed e) {
                        Except.print_exception(e);
                    }
	      }
	      System.out.print("\n");
            } catch (DevFailed devFailed) {
                System.err.println("Error processing event data: " + devFailed.errors[0].desc);
            }
        }
    }

    public class LMCDevStat implements Runnable {
        @Override
	public void run () {
	    int  ms_sleep_selective = 1000;
            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
           
	    while (true) 
	    {
		    LocalDateTime currentDateTime = LocalDateTime.now();
		    String curtime = currentDateTime.format(myFormatObj);


		    if( (ms_sleep_selective / 3000 )  > 0 ) {
			    
                       try {
                           // GlobalVariables.longivityEngineObj.checkProxyStatus();
	                   Long pingvar = deviceProxy.ping();
                           DevState devstate = deviceProxy.state();
			   setDevTimeout(3000);
                           System.out.println( "Client-Time : " + curtime + " STATE "  + devstate + " " + Long.toString(pingvar) );

                       } catch (DevFailed e) {
                             System.err.println("Client-Time : " + curtime + "  devstate-TANGO exception: " + e.errors[0].desc);
			     setDevTimeout(5);
			   
                       } catch (Exception e) {
                             System.err.println("Client-Time : " + curtime + " devstate-Unexpected exception: " + e.getMessage());
			     setDevTimeout(5);
		       }

                       ms_sleep_selective = 100;

                    } else if( (ms_sleep_selective % 1000 )  == 0 ) { // Every 1 second
			   
                       try {
		             DeviceAttribute deviceAttribute = deviceProxy.read_attribute("devtime");
                             if (deviceAttribute.hasFailed()) {
                               Except.print_exception(deviceAttribute.getErrStack()); 
		             } else {
		               System.out.println( "Client-Time : " + curtime + " DEVICETIME VAR  : " +  deviceAttribute.extractString() ) ;
		             }

                       } catch (DevFailed e) {
                             System.err.println( "Client-Time : " + curtime +  " DevTime-TANGO exception: " + e.errors[0].desc);
		             setDevTimeout(5);
                       } catch (Exception e) {
                             System.err.println( "Client-Time : " + curtime + " devTime-Unexpected exception: " + e.getMessage());
		             setDevTimeout(5);
		       }

		    }

		    try {
			Thread.sleep(100);
			ms_sleep_selective += 100;
		    } catch ( InterruptedException e) {
                        System.err.println("InterruptedException : " + e.getMessage());
	            }
            }

       }
    }

    public static void main(String[] args) {

        String deviceName = "tango://c19:10000/test/jdev/1"; // Replace with your device name
        String attributeName = "counter"; // Replace with the attribute you want to subscribe to

        try {
            TangoEventClient example = new TangoEventClient(deviceName);
            example.subscribeToAttribute(attributeName);

            System.out.println("\n\n Subscribed to " + attributeName + ". Waiting for events... (Press Enter to exit)");

            System.in.read(); // Wait for Enter key press
            example.unsubscribeFromAttribute(attributeName);
	   
            System.out.println("Unsubscribed from " + attributeName + ".");
            System.in.read(); // Wait for Enter key press
	    System.exit(0);
        } catch (DevFailed e) {
            System.err.println("TANGO exception: " + e.errors[0].desc);
        } catch (Exception e) {
             System.err.println("Unexpected exception: " + e.getMessage());
        }
    }
}
